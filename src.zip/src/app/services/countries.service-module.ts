import { NgModule } from '@angular/core';
import { CountriesService } from './countries.service';

@NgModule({
  imports: [],
  declarations: [],
  providers: [CountriesService],
  exports: []
})
export class CountriesServiceModule {
}
