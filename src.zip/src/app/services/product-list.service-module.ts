import { NgModule } from '@angular/core';
import { ProductListService } from './product-list.service';

@NgModule({
  imports: [],
  declarations: [],
  providers: [ProductListService],
  exports: []
})
export class ProductListServiceModule {
}
