import { NgModule } from '@angular/core';
import { JobPostsService } from './job-posts.service';

@NgModule({
  imports: [],
  declarations: [],
  providers: [JobPostsService],
  exports: []
})
export class JobPostsServiceModule {
}
