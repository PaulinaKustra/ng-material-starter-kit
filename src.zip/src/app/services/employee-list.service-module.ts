import { NgModule } from '@angular/core';
import { EmployeeListService } from './employee-list.service';

@NgModule({
  imports: [],
  declarations: [],
  providers: [EmployeeListService],
  exports: []
})
export class EmployeeListServiceModule {
}
