import { NgModule } from '@angular/core';
import { InfluencersService } from './influencers.service';

@NgModule({
  imports: [],
  declarations: [],
  providers: [InfluencersService],
  exports: []
})
export class InfluencersServiceModule {
}
