import { NgModule } from '@angular/core';
import { CryptoListService } from './crypto-list.service';

@NgModule({
  imports: [],
  declarations: [],
  providers: [CryptoListService],
  exports: []
})
export class CryptoListServiceModule {
}
