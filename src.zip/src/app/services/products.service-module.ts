import { NgModule } from '@angular/core';
import { ProductsService } from './products.service';

@NgModule({
  imports: [],
  declarations: [],
  providers: [ProductsService],
  exports: []
})
export class ProductsServiceModule {
}
