import { NgModule } from '@angular/core';
import { CategoriesCheckboxService } from './categories-checkbox.service';

@NgModule({
  imports: [],
  declarations: [],
  providers: [CategoriesCheckboxService],
  exports: []
})
export class CategoriesCheckboxServiceModule {
}
