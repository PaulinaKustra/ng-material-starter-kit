import { NgModule } from '@angular/core';
import { CatFactService } from './cat-fact.service';

@NgModule({
  imports: [],
  declarations: [],
  providers: [CatFactService],
  exports: []
})
export class CatFactServiceModule {
}
