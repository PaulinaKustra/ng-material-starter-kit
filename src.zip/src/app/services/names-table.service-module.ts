import { NgModule } from '@angular/core';
import { NamesTableService } from './names-table.service';

@NgModule({
  imports: [],
  declarations: [],
  providers: [NamesTableService],
  exports: []
})
export class NamesTableServiceModule {
}
