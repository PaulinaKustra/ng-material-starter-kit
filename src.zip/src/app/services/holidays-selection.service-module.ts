import { NgModule } from '@angular/core';
import { HolidaysSelectionService } from './holidays-selection.service';

@NgModule({
  imports: [],
  declarations: [],
  providers: [HolidaysSelectionService],
  exports: []
})
export class HolidaysSelectionServiceModule {
}
