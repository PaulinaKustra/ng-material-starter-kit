import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatListModule } from '@angular/material/list';
import { InfluencerListComponent } from './influencer-list.component';

@NgModule({
  imports: [MatListModule, CommonModule],
  declarations: [InfluencerListComponent],
  providers: [],
  exports: [InfluencerListComponent]
})
export class InfluencerListComponentModule {
}
