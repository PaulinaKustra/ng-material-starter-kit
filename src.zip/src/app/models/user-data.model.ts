export interface UserDataModel {
    email: string;
    roleId: number;
    departmentId: number;
    id: string;
    firstName: string;
    lastName: string;
    gender: string;
}

