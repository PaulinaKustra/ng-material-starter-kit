export interface EmployeeModel {
    id: number;
    imageUrl: string;
    firstName: string;
    lastName: string;
    email: string;
    contactNumber: string;
    age: number;
    dob: string;
    salary: number;
    address: string;
  }


