export interface CatFactModel {
  readonly fact: string;
}
