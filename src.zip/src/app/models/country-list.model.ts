export interface CountryListModel {
  name: string;
  id: string;
}
