export interface JobTagsModel {
  name: string;
  id: number;
}
